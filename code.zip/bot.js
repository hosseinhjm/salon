import { PublicClient, AuthenticatedClient, WebsocketClient } from "https://api.prime.coinbase.com";
const publicClient = new PublicClient();

// Set up the API credentials for Coinbase Pro
const key = 'jI6TBEFeA0nRD8Et';
const secret = 'hGz3Tc3RB3Ci5dWpZgvP9wOGkHz9frkC';
// const passphrase = 'your_api_passphrase';
const authedClient = new AuthenticatedClient(key, secret);

// Define your trading strategy
function tradingStrategy(product, ticker) {
  // This is just an example - replace this with your own trading strategy
  if (ticker.price > 1000) {
    console.log(`Placing buy order for ${product} at ${ticker.price}`);
    const buyParams = {
      price: ticker.price,
      size: '0.01',
      product_id: product,
    };
    authedClient.buy(buyParams, (err, response, data) => {
      if (err) console.log(err);
      console.log(data);
    });
  }
}

// Define the product you want to trade
const product = 'BTC-USD';

// Connect to the Coinbase Pro websocket API
const websocket = new WebsocketClient(
  [product],
  'wss://ws-feed.pro.coinbase.com',
  null,
  { channels: ['ticker'] },
);

// Listen for ticker updates and execute your trading strategy
websocket.on('message', (data) => {
  if (data.type === 'ticker') {
    tradingStrategy(product, data);
  }
});

// Log any errors
websocket.on('error', (err) => {
  console.error(err);
});
